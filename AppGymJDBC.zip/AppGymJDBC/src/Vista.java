


import java.sql.Connection;
import java.util.InputMismatchException;
import java.util.Scanner;
public class Vista {

    static Scanner Leer = new Scanner(System.in);
    static Scanner Leer2 = new Scanner(System.in);

    public static Cliente agregarCliente() {
        Cliente c = new Cliente();
        System.out.println("1- Agregar Nuevo Cliente");
        Scanner Leer2 = new Scanner(System.in);
        System.out.println("Ingrese su nombre");
        c.setNombre(Leer2.nextLine());
        System.out.println("Ingrese su apellido");
        c.setApellido(Leer2.nextLine());
        System.out.println("Ingrese su edad");
        c.setEdad(Leer2.nextInt());
        System.out.println("Ingrese su DNI");
        c.setDNI(Leer2.nextInt());
        return c ;

    }

    public static  Couta agregarCouta(){
        Couta co = new Couta();
        Scanner Leer = new Scanner(System.in);
        System.out.println("Crear Plan");
        System.out.println("Seleccione un Plan");
        System.out.println("1 - Mes completo  Precio -- $3000");
        System.out.println("2 - Medio Mes     Precio -- $1500");
        int op = Leer.nextInt();
        if (op == 1) {
            System.out.println("Mes completo");
            co.setMesCompleto(3000);
        }
        else {
            System.out.println("Medio Mes");
            co.setMesMedio(1500);
        }
        return co;
    }

    public static int menuC (){
        try {
            System.out.println("-----------------------------------------");
            System.out.println("Menu Gym");
            System.out.println("1- Agregar Nuevo Cliente");
            System.out.println("2- Ver Clientes Registrados");
            System.out.println("3- Eliminar Clientes Registrados");
            System.out.println("4- Cambiar Couta de Cliente");
            System.out.println("5- Salir");
            System.out.println("-----------------------------------------");
            var opcM = Leer.nextInt();
            return opcM;
        }catch (InputMismatchException ex){
            return 0;
        }
    }

    public  static String eliminarCliente (){
        System.out.println("2- Eliminar Cliente");
        System.out.println("Ingrese el DNI del Cliente que desea Eliminar");
        System.out.println("Ingrese la letra S si quiere volver");
        String rem = Leer2.nextLine();
        return rem;
    }






/*    public static void verClientes ( ResultSet rs) throws SQLException {
        int con=0;
        while (rs.next()){
            con++;
            System.out.println(rs.getInt(1) + " #Nombre:" + rs.getString(2) + " #Apellido:" + rs.getString(3) + " #Edad:" + rs.getInt(4) + " #DNI:" + rs.getInt(5) + " #Couta:" + rs.getInt(6));
        }
        System.out.println("Total de Clientes Registrados: " +con);
    }*/

   /* public  static void buscarCliente (Connection conn) {
        try{
            System.out.println("Ingrese el numero de DNI del Cliente");
            int dni = Leer.nextInt();
            String queryBuscar = "SELECT * From Clientes where DNI ="+dni;
            Statement consulta = conn.createStatement();
            ResultSet registro = consulta.executeQuery(queryBuscar);
            if (registro.next()){
                String nom = registro.getString("DNI");
                System.out.println(registro.getInt(1) + " #Nombre:" + registro.getString(2) +
                        " #Apellido:" + registro.getString(3) + " #Edad:" + registro.getInt(4) +
                        " #DNI:" + registro.getInt(5) + " #Couta:" + registro.getInt(6));
                System.out.println(" ");
                System.out.println("Ingrese la nueva Couta");
                String couta = Leer2.nextLine();
                String queryUp = "UPDATE `gym`.`Clientes` SET Couta = '" + couta + "' WHERE (`DNI` =" + dni + ")";
                int countUpdate = conn.prepareStatement(queryUp).executeUpdate();
                System.out.println("Cambios realizados:"+ countUpdate);
            }else {
                System.out.println("DNI de cliente no encontrado");
            }
            consulta.close();
            registro.close();
            conn.close();
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }*/

 /*   public static int Id (Connection con, PreparedStatement ps , ResultSet rs) {
        int id = 1;
        try{
            ps = con.prepareStatement("Select max(ID) from Clientes");
            rs = ps.executeQuery();
            while (rs.next())
                id = rs.getInt(1)+1;
        }catch (Exception e){
            System.out.println("no hay clientes registrados");
        }
        return id;
    }

    public static void couta(int mesC , int mesM, PreparedStatement QI){
        try{
            if (mesC > mesM) {
                QI.setInt(6, mesC);
            } else {
                QI.setInt(6, mesM);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
*/

}
